<?php 

wp_enqueue_style( 'style-name', get_stylesheet_uri() );
wp_enqueue_style( 'style-bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );



add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );


register_sidebar([
    'name' => 'top Head Left',
    'id' => 'thleft',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'top Head right',
    'id' => 'thright',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'header search',
    'id' => 'search',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'social_links a2i',
    'id' => 'a2i',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'social_links Group icon',
    'id' => 'group_icon',
    'before_widget' => '',
    'after_widget' => ''
]);

register_nav_menus([
    'TM' => 'Primary menu',
    'FM' => 'Footer menu'
]);

register_sidebar([
    'name' => 'banner',
    'id' => 'banner',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'tab_1',
    'id' => 'tab_1',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'tab_2',
    'id' => 'tab_2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'tab_3',
    'id' => 'tab_3',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'tab_4',
    'id' => 'tab_4',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'notice',
    'id' => 'notice',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'ads 1',
    'id' => 'ads_1',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'ads 2',
    'id' => 'ads_2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'ads 3',
    'id' => 'ads_3',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'ads 4',
    'id' => 'ads_4',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'sidebar img ',
    'id' => 'sidebar_img',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'sidebar video ',
    'id' => 'sidebar_video',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'sidebar big img ',
    'id' => 'sidebar_big_img',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'sidebar big img 2',
    'id' => 'sidebar_big_img_2',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'sidebar video 2 ',
    'id' => 'sidebar_video2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'sidebar video 3 ',
    'id' => 'sidebar_video3',
    'before_widget' => '',
    'after_widget' => ''
]);

register_sidebar([
    'name' => 'sidebar img 2',
    'id' => 'sidebar_img_2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'body video 1',
    'id' => 'body_video_1',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'body video 2',
    'id' => 'body_video_2',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'hero exit img',
    'id' => 'exit_img',
    'before_widget' => '',
    'after_widget' => ''
]);
register_sidebar([
    'name' => 'footer right',
    'id' => 'footer_right',
    'before_widget' => '',
    'after_widget' => ''
]);
?>