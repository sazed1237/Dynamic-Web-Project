<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <?php wp_head(); ?>
</head>
<body>
            <section class="container-fluid slider">
            <?php
                $qry1 = new WP_Query([
                    'post_type' => 'post',
                    'category_name' => 'slider'
                ]);            
                ?>
            <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">

        <div class="carousel-inner">

            <?php
            $x = 0;
            while ($qry1->have_posts()):$qry1->the_post();
            $x++;
            ?>
            <div class="carousel-item <?= ($x==1)? 'active' : '' ?>">
                <?php the_post_thumbnail(); ?>
            <!-- <img src="..." class="d-block w-100" alt="..."> -->
            </div>  
            <?php endwhile; ?>          
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
        </div>
            </section>


            <section class="container-fluid logo">
                <div class="row">
                    <div class="col-lg-6">
                        <?php the_custom_logo(); ?>
                    </div>
                    <div class="col-lg-6 text-end">
                        <?php dynamic_sidebar('logoright') ?>
                    </div>
                </div>
            </section>

    
            <section class="container-fluid menu">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
                <div class="collapse navbar-collapse" id="navbarNav">
                    <?php
                    wp_nav_menu([
                        'menu_locations' => 'TM',
                        'menu_class' => 'navbar-nav Project_menu'
                    ]);                    
                    ?>
                <ul class="navbar-nav">
                    <li class="nav-item">
                    <!-- <a class="nav-link active" aria-current="page" href="#">Home</a> -->
                    </li>
                </ul>
                </div>
            </div>
            </nav>
            </section>

            <section class="container hero_heading mt-5">
                <div class="row">
                    <?php dynamic_sidebar('h_heading') ?>
                </div>

                <div class="row mt-5 hero_card">
                    <div class="col-lg-4">
                        <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('h_card1') ?>                    
                        </div>
                    </div>
                    <div class="col-lg-4">
                    <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('h_card2') ?>                    
                        </div>
                    </div>
                    <div class="col-lg-4">
                    <div class="card" style="width: 18rem;">
                        <?php dynamic_sidebar('h_card3') ?>                    
                        </div>
                    </div>
                </div>
            </section>

            <section class="container separator mt-5">
                <div class="row">
                    <div class="col-lg-4 text-end">
                        <img src="<?php echo get_template_directory_uri() . '/assets/image/left.PNG' ?>" alt="">
                    </div>
                    <div class="col-lg-4 text-center">
                        <h5>Recent Photos</h5>
                        <p>Some latest project pictures</p>
                    </div>
                    <div class="col-lg-4">
                    <img src="<?php echo get_template_directory_uri() . '/assets/image/right.PNG' ?>" alt="">
                    </div>
                </div>
            </section>


            <section class="container hero_heading mt-5">
                <div class="row mt-5">
                    <div class="col-lg-3">
                        <div class="card" style="width: 15rem;">
                        <?php dynamic_sidebar('p_card1') ?>                    
                        </div>
                    </div>
                    <div class="col-lg-3">
                    <div class="card" style="width: 15rem;">
                        <?php dynamic_sidebar('p_card2') ?>                    
                        </div>
                    </div>
                    <div class="col-lg-3">
                    <div class="card" style="width: 15rem;">
                        <?php dynamic_sidebar('p_card3') ?>                    
                        </div>
                    </div>
                    <div class="col-lg-3">
                    <div class="card" style="width: 15rem;">
                        <?php dynamic_sidebar('p_card4') ?>                    
                        </div>
                    </div>
                </div>
            </section>


            <section class="container separator mt-5">
                <div class="row">
                    <div class="col-lg-4 text-end">
                        <img src="<?php echo get_template_directory_uri() . '/assets/image/left.PNG' ?>" alt="">
                    </div>
                    <div class="col-lg-4 text-center">
                        <h5>NEWS & EVENTS</h5>
                        <p>CLICK HERE TO VIEW ALL</p>
                    </div>
                    <div class="col-lg-4">
                    <img src="<?php echo get_template_directory_uri() . '/assets/image/right.PNG' ?>" alt="">
                    </div>
                </div>
            </section>


            <section class="container news mt-5">
                <?php
                $qry2 = new WP_Query([
                    'post_type' => 'post',
                    'category_name' => 'news'
                ]);            
                ?>
                <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">

                <div class="carousel-inner">

                    <?php
                    $x = 0;
                    while ($qry2->have_posts()):$qry2->the_post();
                    $x++;
                    ?>
                    <div class="carousel-item <?= ($x==1)? 'active' : '' ?>">
                        <?php the_title(); ?>
                    <!-- <img src="..." class="d-block w-100" alt="..."> -->
                    </div>  
                    <?php endwhile; ?>          
                </div>
            </section>

            <footer class="container-fluid mt-5">
                <section class="container footer_main">
                    <div class="row mt-5">
                        <div class="col-lg-6 f_left mt-5">
                            <?php dynamic_sidebar('f_left') ?>
                        </div>
                        <div class="col-lg-6 f_right mt-5">
                            <?php  dynamic_sidebar('f_right')?>
                        </div>
                    </div>
                    <div class="author mt-5">
                        <div class="row">
                            <div class="col-lg-6">
                                <p>POWERED BY SOLUTION ART LTD</p>
                            </div>
                            <div class="col-lg-6 text-end">
                                <p>COPYRIGHT © 2015. BANGLADESH BRIDGE AUTHORITY.</p>
                            </div>
                        </div>
                    </div>
                </section>
            </footer>

    <?php wp_footer(); ?>
</body>
</html>